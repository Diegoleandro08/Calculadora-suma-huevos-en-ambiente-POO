﻿namespace CALCULADORA
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Pantalla = new System.Windows.Forms.TextBox();
            this.limpiar = new System.Windows.Forms.Button();
            this.b7 = new System.Windows.Forms.Button();
            this.b4 = new System.Windows.Forms.Button();
            this.b1 = new System.Windows.Forms.Button();
            this.bcero = new System.Windows.Forms.Button();
            this.bdivision = new System.Windows.Forms.Button();
            this.b8 = new System.Windows.Forms.Button();
            this.b5 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.bmultiplicacion = new System.Windows.Forms.Button();
            this.b9 = new System.Windows.Forms.Button();
            this.b6 = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.bpunto = new System.Windows.Forms.Button();
            this.bresta = new System.Windows.Forms.Button();
            this.bsuma = new System.Windows.Forms.Button();
            this.braiz = new System.Windows.Forms.Button();
            this.bigual = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Pantalla
            // 
            this.Pantalla.Location = new System.Drawing.Point(12, 12);
            this.Pantalla.Name = "Pantalla";
            this.Pantalla.ReadOnly = true;
            this.Pantalla.Size = new System.Drawing.Size(214, 20);
            this.Pantalla.TabIndex = 0;
            this.Pantalla.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // limpiar
            // 
            this.limpiar.Location = new System.Drawing.Point(12, 38);
            this.limpiar.Name = "limpiar";
            this.limpiar.Size = new System.Drawing.Size(49, 46);
            this.limpiar.TabIndex = 1;
            this.limpiar.Text = "CE";
            this.limpiar.UseVisualStyleBackColor = true;
            this.limpiar.Click += new System.EventHandler(this.limpiar_Click);
            // 
            // b7
            // 
            this.b7.Location = new System.Drawing.Point(12, 90);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(49, 46);
            this.b7.TabIndex = 1;
            this.b7.Text = "7";
            this.b7.UseVisualStyleBackColor = true;
            this.b7.Click += new System.EventHandler(this.b7_Click);
            // 
            // b4
            // 
            this.b4.Location = new System.Drawing.Point(12, 142);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(49, 46);
            this.b4.TabIndex = 1;
            this.b4.Text = "4";
            this.b4.UseVisualStyleBackColor = true;
            this.b4.Click += new System.EventHandler(this.b4_Click);
            // 
            // b1
            // 
            this.b1.Location = new System.Drawing.Point(12, 194);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(49, 46);
            this.b1.TabIndex = 1;
            this.b1.Text = "1";
            this.b1.UseVisualStyleBackColor = true;
            this.b1.Click += new System.EventHandler(this.b1_Click);
            // 
            // bcero
            // 
            this.bcero.Location = new System.Drawing.Point(12, 246);
            this.bcero.Name = "bcero";
            this.bcero.Size = new System.Drawing.Size(104, 46);
            this.bcero.TabIndex = 1;
            this.bcero.Text = "0";
            this.bcero.UseVisualStyleBackColor = true;
            this.bcero.Click += new System.EventHandler(this.button4_Click);
            // 
            // bdivision
            // 
            this.bdivision.Location = new System.Drawing.Point(67, 38);
            this.bdivision.Name = "bdivision";
            this.bdivision.Size = new System.Drawing.Size(49, 46);
            this.bdivision.TabIndex = 1;
            this.bdivision.Text = "/";
            this.bdivision.UseVisualStyleBackColor = true;
            this.bdivision.Click += new System.EventHandler(this.bdivision_Click);
            // 
            // b8
            // 
            this.b8.Location = new System.Drawing.Point(67, 90);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(49, 46);
            this.b8.TabIndex = 1;
            this.b8.Text = "8";
            this.b8.UseVisualStyleBackColor = true;
            this.b8.Click += new System.EventHandler(this.b8_Click);
            // 
            // b5
            // 
            this.b5.Location = new System.Drawing.Point(67, 142);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(49, 46);
            this.b5.TabIndex = 1;
            this.b5.Text = "5";
            this.b5.UseVisualStyleBackColor = true;
            this.b5.Click += new System.EventHandler(this.b5_Click);
            // 
            // b2
            // 
            this.b2.Location = new System.Drawing.Point(67, 194);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(49, 46);
            this.b2.TabIndex = 1;
            this.b2.Text = "2";
            this.b2.UseVisualStyleBackColor = true;
            this.b2.Click += new System.EventHandler(this.b2_Click);
            // 
            // bmultiplicacion
            // 
            this.bmultiplicacion.Location = new System.Drawing.Point(122, 38);
            this.bmultiplicacion.Name = "bmultiplicacion";
            this.bmultiplicacion.Size = new System.Drawing.Size(49, 46);
            this.bmultiplicacion.TabIndex = 1;
            this.bmultiplicacion.Text = "*";
            this.bmultiplicacion.UseVisualStyleBackColor = true;
            this.bmultiplicacion.Click += new System.EventHandler(this.bmultiplicacion_Click);
            // 
            // b9
            // 
            this.b9.Location = new System.Drawing.Point(122, 90);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(49, 46);
            this.b9.TabIndex = 1;
            this.b9.Text = "9";
            this.b9.UseVisualStyleBackColor = true;
            this.b9.Click += new System.EventHandler(this.b9_Click);
            // 
            // b6
            // 
            this.b6.Location = new System.Drawing.Point(122, 142);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(49, 46);
            this.b6.TabIndex = 1;
            this.b6.Text = "6";
            this.b6.UseVisualStyleBackColor = true;
            this.b6.Click += new System.EventHandler(this.b6_Click);
            // 
            // b3
            // 
            this.b3.Location = new System.Drawing.Point(122, 194);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(49, 46);
            this.b3.TabIndex = 1;
            this.b3.Text = "3";
            this.b3.UseVisualStyleBackColor = true;
            this.b3.Click += new System.EventHandler(this.b3_Click);
            // 
            // bpunto
            // 
            this.bpunto.Location = new System.Drawing.Point(122, 246);
            this.bpunto.Name = "bpunto";
            this.bpunto.Size = new System.Drawing.Size(49, 46);
            this.bpunto.TabIndex = 1;
            this.bpunto.Text = ".";
            this.bpunto.UseVisualStyleBackColor = true;
            this.bpunto.Click += new System.EventHandler(this.bpunto_Click);
            // 
            // bresta
            // 
            this.bresta.Location = new System.Drawing.Point(177, 38);
            this.bresta.Name = "bresta";
            this.bresta.Size = new System.Drawing.Size(49, 46);
            this.bresta.TabIndex = 1;
            this.bresta.Text = "-";
            this.bresta.UseVisualStyleBackColor = true;
            this.bresta.Click += new System.EventHandler(this.bresta_Click);
            // 
            // bsuma
            // 
            this.bsuma.Location = new System.Drawing.Point(177, 90);
            this.bsuma.Name = "bsuma";
            this.bsuma.Size = new System.Drawing.Size(49, 46);
            this.bsuma.TabIndex = 1;
            this.bsuma.Text = "+";
            this.bsuma.UseVisualStyleBackColor = true;
            this.bsuma.Click += new System.EventHandler(this.bsuma_Click);
            // 
            // braiz
            // 
            this.braiz.Location = new System.Drawing.Point(177, 142);
            this.braiz.Name = "braiz";
            this.braiz.Size = new System.Drawing.Size(49, 46);
            this.braiz.TabIndex = 1;
            this.braiz.Text = "raiz";
            this.braiz.UseVisualStyleBackColor = true;
            this.braiz.Click += new System.EventHandler(this.braiz_Click);
            // 
            // bigual
            // 
            this.bigual.Location = new System.Drawing.Point(177, 194);
            this.bigual.Name = "bigual";
            this.bigual.Size = new System.Drawing.Size(49, 97);
            this.bigual.TabIndex = 1;
            this.bigual.Text = "=";
            this.bigual.UseVisualStyleBackColor = true;
            this.bigual.Click += new System.EventHandler(this.bigual_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(242, 303);
            this.Controls.Add(this.bpunto);
            this.Controls.Add(this.bcero);
            this.Controls.Add(this.bigual);
            this.Controls.Add(this.b3);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.b1);
            this.Controls.Add(this.braiz);
            this.Controls.Add(this.bsuma);
            this.Controls.Add(this.b6);
            this.Controls.Add(this.b9);
            this.Controls.Add(this.b5);
            this.Controls.Add(this.bresta);
            this.Controls.Add(this.b8);
            this.Controls.Add(this.bmultiplicacion);
            this.Controls.Add(this.b4);
            this.Controls.Add(this.bdivision);
            this.Controls.Add(this.b7);
            this.Controls.Add(this.limpiar);
            this.Controls.Add(this.Pantalla);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Pantalla;
        private System.Windows.Forms.Button limpiar;
        private System.Windows.Forms.Button b7;
        private System.Windows.Forms.Button b4;
        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Button bcero;
        private System.Windows.Forms.Button bdivision;
        private System.Windows.Forms.Button b8;
        private System.Windows.Forms.Button b5;
        private System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button bmultiplicacion;
        private System.Windows.Forms.Button b9;
        private System.Windows.Forms.Button b6;
        private System.Windows.Forms.Button b3;
        private System.Windows.Forms.Button bpunto;
        private System.Windows.Forms.Button bresta;
        private System.Windows.Forms.Button bsuma;
        private System.Windows.Forms.Button braiz;
        private System.Windows.Forms.Button bigual;
    }
}

